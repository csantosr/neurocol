<template>
  <div class="container">
    <div class="right" :style="`background-color: ${colors['lemonMeringue']}`">
      <!-- <FontAwesomeIcon icon="brain" :style="{
        color: colors['prussianBlue'],
        width: '15vw',
        height: '15vw'
      }" /> -->
    </div>
    <div class="left" :style="`background-color: ${colors['prussianBlue']}`">
      <div class="formWrapper">
        <div class="form">
          <h1 class="form-title" :style="{color: colors['lemonMeringue']}">Bienvenido</h1>
          <div class="error_wrapper" v-if="hasError">
            <h3 class="form-title error_msg">{{ errorMsg }}</h3>
          </div>
          <label for="username" :style="{color: colors['lemonMeringue']}">Nombre de usuario</label>
          <input type="text" class="inp username" id="username" v-model="username">
          <label for="password" :style="{color: colors['lemonMeringue']}">Contraseña</label>
          <input type="password" class="inp password" id="password" v-model="password">
          <br>
          <button
            class="login-btn"
            @click="login"
            :style="{'background-color': colors['lemonMeringue']}"
          >
            Iniciar sesión
          </button>
          <div class="linkWrapper">
            <a href="/register" :style="{color: colors['maximumYellowRed']}">
              Registrarse como asistente
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Http from "../lib/http";
import colorsJson from '../styles/colors.json';

export default {
  name: "Login",
  methods: {
    async login() {
      this.loading = true;
      this.hasError = false;
      const http = new Http();
      const response = await http.post("/auth/login", {
        username: this.username,
        password: this.password,
      });
      if (response.error) {
        this.errorMsg = "Hubo un error accediendo al servidor. Inténtelo más tarde o comuníquese con el Administrador";
        this.hasError = true;
        this.loading = false;
      } else {
        if (response.status === 200) {
          localStorage.setItem('user', JSON.stringify(response.data.user));
          localStorage.setItem('token', response.data.user.token);
          localStorage.setItem('group_id', response.data.user.group_id);
          this.loading = false;
          if (response.data.user.group_id == 1) {
            this.$router.push('/admin');
          } else if (response.data.user.group_id == 3) {
            this.$router.push('/organizer');
          } else if (response.data.user.group_id == 4) {
            this.$router.push('/attendee');
          }
        } else if (response.status >= 400 && response.status <= 500) {
          this.errorMsg = "Usuario y contraseña no válidas.";
          this.hasError = true;
          this.loading = false;
        } else {
          this.errorMsg = "Error interno. Inténtelo más tarde.";
          this.hasError = true;
          this.loading = false;
        }
      }
    },
  },
  data() {
    return {
      username: "",
      password: "",
      hasError: false,
      errorMsg: "",
      loading: false,
      colors: colorsJson,
    };
  },
};
</script>

<style scoped>
  .container {
    border: 0;
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: row;
  }
  .right, .left{
    width: 50vw;
  }
  .right {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .left {
    padding-top: 5%;
    padding-bottom: 5%;
    padding-left: 5%;
    padding-right: 5%;
  }
  .error_wrapper {
    padding-left: 2em;
    padding-right: 2em;
    background-color: #D62828;
    border-radius: 2em;
    color: white !important;
  }
  .error_msg {
    padding: 0 !important;
    /* margin: 0 !important; */
  }
  .formWrapper {
    border-radius: 5px;
  }
  .form {
    display: flex;
    flex-direction: column;
  }
  .inp {
    margin-top: 5px;
    border: 0;
    padding: 10px;
    border-radius: 10px;
  }
  textarea:focus, input:focus{
    outline: none;
  }
  .form-title {
    font-family: 'Titillium Web', sans-serif;
    font-weight: 700;
  }
  label {
    margin-top: 5px;
    font-family: 'Titillium Web', sans-serif;
    font-weight: 200;
  }
  .login-btn {
    margin-top: 15px;
    padding: 10px;
    border-radius: 10px;
    font-family: 'Titillium Web', sans-serif;
    font-weight: 300;
    font-size: 16px;
    cursor: pointer;
  }
  .linkWrapper {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .linkWrapper > a {
    font-family: 'Titillium Web', sans-serif;
    font-weight: 300;
    font-size: 12px;
    text-decoration: none;
  }
  .form-title {
    font-family: 'Titillium Web', sans-serif;
    font-weight: 700;
  }
</style>