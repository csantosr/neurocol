<template>
  <div class="wrapper">
    <div class="rigth-logo center-img">
      <img src="../../assets/IBRO2021.jpg" alt="" srcset="">
    </div>
    <div class="left-logo center-img">
      <img src="../../assets/Areandina-Logo.jpg" alt="" srcset="">
    </div>
  </div>
</template>

<script>
export default {
  name: "HomeAdmin",
};
</script>

<style scoped lang="scss">
.wrapper {
  height: calc(100vh - 30px);
  width: 100%;
  // background-color: $bg;
  // filter: grayscale(100%);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center;
  display: flex;
  flex-direction: row;
}
.rigth-logo {
  height: 100%;
  width: 50%;
}
.left-logo {
  height: 100%;
  width: 50%;
}
.center-img {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 1em;

  img {
    max-width: 100%;
  }
}
</style>