<template>
  <div class="main-container">
    <h2 class="header__title dark-text regular-font">Generar Certificado</h2>
    <p class="dark-text regular-font">Has completado un
      <span class="bold-font">{{Number.parseFloat(attendancePercentage * 100).toFixed(2)}}%</span>
      del evento
    </p>
    <p class="dark-text regular-font" v-if="attendancePercentage !== 1">Los eventos que no has visto son:</p>
    <ul>
      <li
        class="dark-text regular-font"
        v-for="event in eventsLeft"
        :key="event.event_id">
        <router-link :to="`/attendee/events/${event.event_id}`">{{event.title}}</router-link>
      </li>
    </ul>
    <div class="certificate-actions">
      <button
        :class="{'btn': true, 'btn-lg': true, 'btn-success': true, 'btn-disabled': attendance.length < 1}"
        :disabled="attendance.length < 1"
        @click="getCertificate()">Descargar certificado</button>
    </div>
  </div>
</template>

<script>
import Http from '../../../lib/http';
import { jsPDF } from 'jspdf';
import Base64 from 'base-64'

export default {
  name: 'AttendeeCertificate',
  beforeMount() {
    this.getCertificateLog();
  },
  methods: {
    getCertificate() {
      const {first_name, last_name} = JSON.parse(
        localStorage.getItem('user'),
      );
      const doc = new jsPDF({
        orientation: "landscape",
        unit: "in",
      });
      doc.setFontSize(20);
      doc.text("CERTIFICADO DE PARTICIPACIÓN", 5.875, 1, {
        align: 'center',
      });
      doc.setFontSize(16);
      doc.text("Otorgado a", 5.875, 2, {
        align: 'center',
      });
      doc.setFontSize(26);
      doc.text(`${first_name} ${last_name}`, 5.875, 3, {
        align: 'center',
      });
      doc.setFontSize(16);
      doc.text(`Por haber asistido de manera asincrónica a ${this.attendance.length} charla${
        this.attendance.length > 1
          ? 's'
          : ''} de la Semana del Cerebro, Colombia, 2021.`, 5.875, 4, {
        align: 'center',
      });

      const ibroLogo = 'data:image/jpeg;base64,' + Base64.encode('../../assets/IBRO2021.jpg')

      // doc.setFontSize(16);
      // doc.text('Firma 1.', 5.875-2.93, 7, {
      //   align: 'center',
      // });
      doc.addImage(ibroLogo, 'JPEG', 3, 7, 2, 3)
      doc.setFontSize(16);
      doc.text('Firma 2.', 5.875+2.93, 7, {
        align: 'center',
      });
      doc.save("two-by-four.pdf");
    },
    getCertificateLog() {
      const { user_id } = JSON.parse(
        localStorage.getItem('user'),
      );
      const http = new Http();
      http
        .authGet(`/event/attendance/${user_id}`)
        .then(({status, data}) => {
          console.log(data)
          if (!data.error) {
            console.log(data.attendance.length)
            this.attendance = data.attendance;
            this.attendancePercentage = data.attendancePercentage;
            this.eventsLeft = data.eventsLeft;
          }
        });
    },
  },
  data() {
    return {
      attendance: [],
      attendancePercentage: 0,
      eventsLeft: [],
    };
  },
}
</script>

<style lang="scss" scoped>
.certificate-actions {
  width: 100%;
  display: flex;
  justify-content: center;
}
.btn-disabled {
  background-color: #5A5A5A !important;
  cursor: not-allowed;
}
</style>