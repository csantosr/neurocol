<template>
  <div class="wrapper"></div>
</template>

<script>
export default {
  name: "HomeOrganizer",
};
</script>

<style scoped lang="scss">
.wrapper {
  height: calc(100vh - 30px);
  width: 100%;
  background-color: $bg;
  filter: grayscale(100%);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center;
}
</style>