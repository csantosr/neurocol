<template>
  <div class="view-event__wrapper" v-if="!loading">
    <div class="view-event__video">
      <div class="video" v-html="event.yt_link"></div>
    </div>
    <div class="view-event__information">
      <h2 class="header__title dark-text bold-font">{{event.title}}</h2>
      <span class="dark-text light-font">{{event.speaker.name}}</span>
      <h4 class="header__title dark-text regular-font">{{event.event_description}}</h4>
    </div>
  </div>
</template>

<script>
import Http from '../../../lib/http';
export default {
  name: 'ViewEvent',
  beforeMount() {
    this.getEvent();
  },
  methods: {
    getEvent() {
      this.loading = true;
      const http = new Http();
      http
        .authGet(`/event/${this.$route.params.event_id}`)
        .then(({data, status}) => {
          if (!data.error) {
            this.event = data.event;
            const { user_id } = JSON.parse(
              localStorage.getItem('user'),
            );
            http
              .authPut(`/event/${this.$route.params.event_id}/check-in`, {user_id})
              .then(({data: dataCheckin, status: statusCheckin}) => {
                if (!dataCheckin.error) {
                  this.loading = false;
                }
              });
          }
        })
    },
  },
  data() {
    return {
      event: {},
      loading: false,
      video_iframe: '<iframe width="560" height="420" src="https://www.youtube.com/embed/-H9N9RLEZYE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>',
    };
  },
}
</script>

<style lang="scss" scoped>
  .view-event {
    &__wrapper {
      height: calc(100vh - 30px);
      width: 100%;
    }
    &__video {
      background-color: black;
      padding: 20px;
      display: flex;
      justify-content: center;
    }
    &__information {
      padding: 2em;
      h2 {
        margin-bottom: 0 !important;
      }
    }
  }
</style>