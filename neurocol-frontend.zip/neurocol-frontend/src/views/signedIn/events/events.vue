<template>
  <list-model 
    title="Eventos"
    :table_info="{
      columns: [
        { query: 'event_id', verbose: 'ID' },
        { query: 'title', verbose: 'Título' },
        { query: 'event_timestamp', verbose: 'Fecha' }
      ],
      actions: [],
      api_endpoint: '/event',
      sorting_column: 'event_id'
    }"
    @go-to-create="goToCreate"
    @go-to-update="goToUpdate"
    @go-to-delete="goToDelete"
    @go-to-detail="goToDetail"
  />
</template>

<script>
import Http from '../../../lib/http';
import listModel from '../../../components/listModel.vue';

export default {
  components: { listModel },
  name: 'EventsAdmin',
  methods: {
    getEvents() {
      const http = new Http();

      http
        .get(`/event`)
        .then(({data, status}) => {
          if (data.error) {
            this.error = true;
          } else {
            this.events = data.results;
          }
        })
    },
    goToCreate() {
      this.$router.push({
        name: "createEvent",
      });
    },
    goToUpdate(id) {},
    goToDelete(id) {},
    goToDetail(id) {},
  },
  data() {
    return {
      events: [],
      error: false,
    };
  }
}
</script>

<style>

</style>