<template>
  <div class="main-container">
    <div class="header">
      <h2 class="header__title dark-text regular-font">Crear Evento</h2>
    </div>
    <form @submit.prevent="saveEvent()">
      <div class="form-group">
        <label for="title" class="light-font dark-text">Título</label>
        <input type="text" name="title" id="title" v-model="title" />
      </div>
      <div class="form-group">
        <label for="texta" class="light-font dark-text">Descripción del evento</label>
        <textarea name="event_description" id="event_description" cols="30" rows="10" v-model="event_description"></textarea>
      </div>
      <div class="form-group">
        <label for="event_time" class="light-font dark-text">Fecha y hora del evento</label>
        <input type="datetime-local" name="event_time" id="event_time" v-model="event_time" />
      </div>
      <div class="form-group">
        <label for="yt_link" class="light-font dark-text">Video de youtube (Embebido)</label>
        <input type="text" name="yt_link" id="yt_link" v-model="yt_link" />
      </div>
      <div class="form-group">
        <label for="therapy" class="light-font dark-text">Conferencista</label>
        <select
          name="speaker_id"
          id="speaker_id"
          class="light-font"
          v-model="speaker_id"
        >
          <option value="1" v-if="loading_speakers" class="light-italic-font">
            Cargando ...
          </option>
          <option
            :value="speaker.speaker_id"
            v-for="speaker in speakers"
            :key="speaker.speaker_id"
          >
            {{ speaker.user.first_name }} {{ speaker.user.last_name }}
          </option>
        </select>
      </div>
      <div class="form-actions">
        <button
          type="submit"
          class="btn btn-success btn-lg">Crear Evento</button>
      </div>
    </form>
  </div>
</template>

<script>
import Http from '../../../lib/http';
export default {
  name: 'CreateEvent',
  beforeMount() {
    this.getSpeakers();
  },
  methods: {
    getSpeakers() {
      this.loading_speakers = true;
      const http = new Http();
      http
        .authGet('/speaker')
        .then(({status, data}) => {
          if (status < 300) {
            this.speakers = data.results;
            this.loading_speakers = false;
          }
        })
    },
    saveEvent() {
      const http = new Http();
      http
        .authPost('/event', {
          "event": {
            "title": this.title,
            "event_description": this.event_description,
            "event_timestamp": this.event_time,
            "yt_link": this.yt_link,
            "yt_key": "yt_key",
            "speaker_id": this.speaker_id
          }
        })
        .then((response) => {
          if (response.status === 201) {
            this.$router.push({
              name: "adminEvents",
            });
          }
        });
    },
  },
  data() {
    return {
      loading_speakers: false,
      speakers: [],

      title: '',
      event_description: '',
      event_time: '',
      yt_link: '',
      speaker_id: null,
    };
  },
}
</script>

<style lang="scss" scoped>
.form-group {
  width: 100%;
  display: flex;
  flex-direction: column;

  * {
    display: block;
  }
  label {
    margin-bottom: 5px;
  }
  textarea {
    resize: none;
  }
  input,
  textarea,
  select {
    margin-bottom: 10px;
    padding: 5px;
    padding-left: 10px;
    padding-right: 10px;
    border-radius: 10px;
    border: 0;
    background-color: $light;
  }
  input.has-error,
  textarea.has-error,
  select.has-error {
    border: 1px solid $danger;
  }
  input::placeholder,
  textarea::placeholder {
    @extend .regular-italic-font;
  }
  &.form-checkbox {
    flex-direction: row;
    align-items: center;
    margin-bottom: 10px;
    input {
      margin: 0;
      margin-left: 10px;
    }
    label {
      margin-bottom: 0;
    }
  }
}

.form-actions {
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
}
</style>