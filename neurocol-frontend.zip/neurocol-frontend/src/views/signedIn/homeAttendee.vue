<template>
  <div class="main-container">
    <div class="header">
      <h2 class="header__title dark-text regular-font">Eventos</h2>
    </div>
    <div class="events">
      <div
        class="event"
        v-for="event in events"
        :key="event.event_id"
        @click="goToEvent(event.event_id)">
        <div class="event-title">
          <p class="bold-font">{{ event.title }}</p>
          <span class="light-font">{{ event.speaker.name }}</span>
        </div>
        <div class="event-action">
          <component :is="PlayCircleOutline" class="event-icon"></component>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { PlayCircleOutline } from "mdue";
import Http from '../../lib/http';

export default {
  name: "Home",
  components: [ PlayCircleOutline ],
  beforeMount() {
    this.getEvents();
  },
  methods: {
    getEvents() {
      const http = new Http();
      http
        .get(`/event`)
        .then(({data, status}) => {
          if (data.error) {
            this.error = true;
          } else {
            this.events = data.results;
          }
        })
    },
    goToEvent(event_id) {
      this.$router.push({
        name: "ViewEvent",
        params: {
          event_id,
        }
      });
    }
  },
  data() {
    return {
      PlayCircleOutline,
      events: [],
      error: false,
    };
  }
};
</script>

<style scoped lang="scss">
.wrapper {
  height: calc(100vh - 30px);
  width: 100%;
  background-color: $bg;
  filter: grayscale(100%);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center;
}
.events {
  width: 100%;
  display: grid;
	grid-gap: 0.5em;
	grid-template-columns: repeat(auto-fill, minmax(500px, 1fr));
	@media screen and (max-width: 320px) {
		grid-template-columns: repeat(auto-fill, minmax(100%, 500px));
	}
}
.event {
  background: $dark;
  border-radius: 10px;
  padding: 20px;
  color: white;
  display: grid;
  grid-template-columns: 1fr 100px;
  cursor: pointer;
  p {
    margin: 0 !important
  }
}
.event-title {
  height: 100%;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.event-action {
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}
.event-icon {
  height: 3em;
  width: 3em;
}
</style>