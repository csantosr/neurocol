<template>
  <div class="main-container">
    <div class="header">
      <h2 class="header__title dark-text regular-font">Crear Conferencista</h2>
    </div>
    <form @submit.prevent="saveSpeaker()">
      <div class="form-group">
        <label for="first_name" class="light-font dark-text">Nombres</label>
        <input type="text" name="first_name" id="first_name" v-model="first_name" />
      </div>
      <div class="form-group">
        <label for="last_name" class="light-font dark-text">Apellidos</label>
        <input type="text" name="last_name" id="last_name" v-model="last_name" />
      </div>
      <div class="form-group">
        <label for="email" class="light-font dark-text">Correo Electrónico</label>
        <input type="text" name="email" id="email" v-model="email" />
      </div>
      <div class="form-group">
        <label for="speaker_bio" class="light-font dark-text">Biografía</label>
        <textarea name="speaker_bio" id="speaker_bio" cols="30" rows="10" v-model="speaker_bio"></textarea>
      </div>
      <div class="form-actions">
        <button
          type="submit"
          class="btn btn-success btn-lg">Crear Conferencista</button>
      </div>
    </form>
  </div>
</template>

<script>
import Http from '../../../lib/http';
export default {
  name: 'CreateEvent',
  methods: {
    saveSpeaker() {
      const http = new Http();
      http
        .authPost('/speaker', {
          user: {
            first_name: this.first_name,
            last_name: this.last_name,
            document: this.email,
            username: this.email,
            password: this.email,
            email: this.email,
            group: {
              group_id: 2,
              group_name: "Speaker"
            }
          },
          speaker: {
            speaker_bio: this.speaker_bio,
            speaker_photo: ""
          }
        })
        .then((response) => {
          if (response.status === 201) {
            this.$router.push({
              name: "adminSpeakers",
            });
          }
        });
    },
  },
  data() {
    return {
      first_name: '',
      last_name: '',
      email: '',
      speaker_bio: '',
    };
  },
}
</script>

<style lang="scss" scoped>
.form-group {
  width: 100%;
  display: flex;
  flex-direction: column;

  * {
    display: block;
  }
  label {
    margin-bottom: 5px;
  }
  textarea {
    resize: none;
  }
  input,
  textarea,
  select {
    margin-bottom: 10px;
    padding: 5px;
    padding-left: 10px;
    padding-right: 10px;
    border-radius: 10px;
    border: 0;
    background-color: $light;
  }
  input.has-error,
  textarea.has-error,
  select.has-error {
    border: 1px solid $danger;
  }
  input::placeholder,
  textarea::placeholder {
    @extend .regular-italic-font;
  }
  &.form-checkbox {
    flex-direction: row;
    align-items: center;
    margin-bottom: 10px;
    input {
      margin: 0;
      margin-left: 10px;
    }
    label {
      margin-bottom: 0;
    }
  }
}

.form-actions {
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
}
</style>