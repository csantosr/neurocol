<template>
  <list-model 
    title="Conferencistas"
    :table_info="{
      columns: [
        { query: 'speaker_id', verbose: 'ID' },
        { query: 'user.first_name', verbose: 'Nombres' },
        { query: 'user.last_name', verbose: 'Apellidos' },
        // { query: 'description', verbose: 'Descripción' }
      ],
      actions: [], //['detail', 'update', 'delete'],
      api_endpoint: '/speaker',
      sorting_column: 'speaker_id'
    }"
    @go-to-create="goToCreate"
    @go-to-update="goToUpdate"
    @go-to-delete="goToDelete"
    @go-to-detail="goToDetail"
  />
</template>

<script>
import Http from '../../../lib/http';
import listModel from '../../../components/listModel.vue';

export default {
  components: { listModel },
  name: 'EventsAdmin',
  methods: {
    getEvents() {
      const http = new Http();

      http
        .get(`/event`)
        .then(({data, status}) => {
          if (data.error) {
            this.error = true;
          } else {
            this.events = data.events;
          }
        })
    },
    goToCreate() {
      this.$router.push({
        name: "createSpeaker",
      });
    },
    goToUpdate(id) {},
    goToDelete(id) {},
    goToDetail(id) {},
  },
  data() {
    return {
      events: [],
      error: false,
    };
  }
}
</script>

<style>

</style>