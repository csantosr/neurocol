<template>
  <div class="container">
    <div class="right" :style="`background-color: ${colors['lemonMeringue']}`">
      <!-- <FontAwesomeIcon icon="brain" :style="{
        color: colors['prussianBlue'],
        width: '15vw',
        height: '15vw'
      }" /> -->
    </div>
    <div class="left" :style="`background-color: ${colors['prussianBlue']}`">
      <div class="formWrapper">
        <div class="form">
          <h1 class="form-title" :style="{color: colors['lemonMeringue']}">
            Regístrate como asistente
          </h1>

          <div class="error_wrapper" v-if="hasError">
            <h3 class="form-title error_msg">{{ errorMsg }}</h3>
          </div>

          <div class="success_wrapper" v-if="hasRegistered">
            <h3 class="form-title success_msg">
              Registro exitoso, <a href="/login">inicie sesión</a>
            </h3>
          </div>

          <label for="first_name" :style="{color: colors['lemonMeringue']}">Nombres</label>
          <input type="text" class="inp" id="first_name" v-model="first_name" :disabled="hasRegistered">

          <label for="last_name" :style="{color: colors['lemonMeringue']}">Apellidos</label>
          <input type="text" class="inp" id="last_name" v-model="last_name" :disabled="hasRegistered">

          <label for="document" :style="{color: colors['lemonMeringue']}">
            Numero de documento
          </label>
          <input type="text" class="inp" id="document" v-model="document" :disabled="hasRegistered">

          <label for="username" :style="{color: colors['lemonMeringue']}">
            Nombre de usuario
          </label>
          <input type="text" class="inp" id="username" v-model="username" :disabled="hasRegistered">

          <label for="email" :style="{color: colors['lemonMeringue']}">
            Correo electrónico
          </label>
          <input type="text" class="inp" id="email" v-model="email" :disabled="hasRegistered">

          <label for="password" :style="{color: colors['lemonMeringue']}">Contraseña</label>
          <input type="password" class="inp" id="password" v-model="password" :disabled="hasRegistered">

          <label for="password_again" :style="{color: colors['lemonMeringue']}">
            Repite tu contraseña
          </label>
          <input type="password" class="inp" id="password_again" v-model="password_again" :disabled="hasRegistered">

          <br>

          <label for="organization" :style="{color: colors['lemonMeringue']}">
            Organización
          </label>
          <input type="text" class="inp" id="organization" v-model="organization" :disabled="hasRegistered">

          <br>

          <button
            v-on:click="register"
            :style="{'background-color': colors['lemonMeringue']}"
            :disabled="hasRegistered">
            Registrarse
          </button>
          <div class="linkWrapper">
            <a href="/login" :style="{color: colors['maximumYellowRed']}">Iniciar sesión</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Http from "../lib/http";
import Storage from "../lib/storage";
import colorsJson from '../styles/colors.json';
// import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'

/*
{
  user: {
    first_name: string, X
    last_name: string, X
    document: string, X
    username: string, X
    password: string, X
    email: string, X
    group: {
      group_id: 4,
      group_name: 'Attendee',
    },
  },
  organization: {
    organization_name: string;
  }
}

*/

export default {
  name: "Register",
  methods: {
    async register() {
      this.loading = true;
      this.hasError = false;

      if (
        this.first_name.length <= 0 ||
        this.last_name.length <= 0 ||
        this.document.length <= 0 ||
        this.username.length <= 0 ||
        this.password.length <= 0 ||
        this.password_again.length <= 0 ||
        this.email.length <= 0 ||
        this.organization.length <= 0
      ) {
        this.errorMsg = "Hay un error en el formulario";
        this.hasError = true;
        this.loading = false;
        return;
      }

      const http = new Http();
      const response = await http.post("/auth/attendeeRegister", {
        user: {
          first_name: this.first_name,
          last_name: this.last_name,
          document: this.document,
          username: this.username,
          password: this.password,
          email: this.email,
          group: {
            group_id: 4,
            group_name: 'Attendee',
          },
        },
        organization: {
          organization_name: this.organization_name,
        }
      });
      if (response.error) {
        this.errorMsg = "Hubo un error accediendo al servidor. Inténtelo más tarde o comuníquese con el Administrador";
        this.hasError = true;
        this.loading = false;
      } else {
        console.log(response);
        if (response.status === 201) {
          this.hasRegistered = true;
        } else {
          this.errorMsg = "Error interno. Inténtelo más tarde.";
          this.hasError = true;
          this.loading = false;
        }
      }
    },
  },
  data() {
    return {
      first_name: "",
      last_name: "",
      document: "",
      username: "",
      email: "",
      password: "",
      password_again: "",
      organization: "",
      hasError: false,
      errorMsg: "",
      loading: false,
      hasRegistered: false,
      colors: colorsJson,
    };
  },
};
</script>

<style scoped>
  .container {
    border: 0;
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: row;
  }
  .error_wrapper {
    padding-left: 2em;
    padding-right: 2em;
    background-color: #D62828;
    border-radius: 2em;
    color: white !important;
  }
  .success_wrapper {
    padding-left: 2em;
    padding-right: 2em;
    background-color: #22bb33;
    border-radius: 2em;
    color: white !important;
  }
  .error_msg {
    padding: 0 !important;
    /* margin: 0 !important; */
  }
  .right, .left{
    width: 50vw;
    overflow: scroll;
  }
  .right {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .left {
    padding-top: 5%;
    padding-bottom: 5%;
    padding-left: 5%;
    padding-right: 5%;
  }
  .formWrapper {
    border-radius: 5px;
  }
  .form {
    display: flex;
    flex-direction: column;
  }
  .inp {
    margin-top: 5px;
    border: 0;
    padding: 10px;
    border-radius: 10px;
  }
  textarea:focus, input:focus{
    outline: none;
  }
  .form-title {
    font-family: 'Titillium Web', sans-serif;
    font-weight: 700;
  }
  label {
    margin-top: 5px;
    font-family: 'Titillium Web', sans-serif;
    font-weight: 200;
  }
  button {
    margin-top: 15px;
    padding: 10px;
    border-radius: 10px;
    font-family: 'Titillium Web', sans-serif;
    font-weight: 300;
    font-size: 16px;
  }
  .linkWrapper {
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .linkWrapper > a {
    font-family: 'Titillium Web', sans-serif;
    font-weight: 300;
    font-size: 12px;
    text-decoration: none;
  }
</style>