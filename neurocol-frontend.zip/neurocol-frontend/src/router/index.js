import { createWebHistory, createRouter } from "vue-router";
import Login from "@/views/login";
import Register from "@/views/register"
import HomeAttendee from "@/views/signedIn/homeAttendee";
import HomeAdmin from "@/views/signedIn/homeAdmin";
import EventsAdmin from "@/views/signedIn/events/events";
import createEvent from "@/views/signedIn/events/create-event";
import SpeakersAdmin from "@/views/signedIn/speakers/speakers";
import createSpeaker from "@/views/signedIn/speakers/create-speaker";
import HomeOrganizer from "@/views/signedIn/homeOrganizer";
import SignedIn from "@/views/signedIn/signedIn";
import ViewEvent from "@/views/signedIn/events/view-event.vue";
import AttendeeCertificate from "@/views/signedIn/certificate/certificate.vue";

const routes = [
  {
    path: "/login",
    name: "login",
    component: Login,
    beforeEnter: (to, from, next) => {
      if (localStorage.getItem("token")) {
        goHome(next);
      } else {
        next();
      }
    },
  },
  {
    path: "/register",
    name: "register",
    component: Register,
    beforeEnter: (to, from, next) => {
      if (localStorage.getItem("token")) {
        goHome(next);
      } else {
        next();
      }
    },
  },
  {
    path: "/",
    name: "signedIn",
    component: SignedIn,
    meta: { requiresAuth: true },
    children: [
      {
        path: "/attendee",
        name: "attendee",
        component: HomeAttendee,
        meta: {
          requiresAuth: true,
          attendee: true,
        },
      },
      {
        path: "/attendee/certificate",
        name: "attendeeCertificate",
        component: AttendeeCertificate,
        meta: {
          requiresAuth: true,
          attendee: true,
        },
      },
      {
        path: "/attendee/events/:event_id",
        name: "ViewEvent",
        component: ViewEvent,
        meta: {
          requiresAuth: true,
          attendee: true,
        },
      },
      {
        path: "/organizer",
        name: "organizer",
        component: HomeOrganizer,
        meta: {
          requiresAuth: true,
          organizer: true,
        },
      },
      {
        path: "/admin",
        name: "admin",
        component: HomeAdmin,
        meta: {
          requiresAuth: true,
          admin: true,
        },
      },
      {
        path: "/admin/events",
        name: "adminEvents",
        component: EventsAdmin,
        meta: {
          requiresAuth: true,
          admin: true,
          organizer: true,
        },
      },
      {
        path: "/admin/events/create",
        name: "createEvent",
        component: createEvent,
        meta: {
          requiresAuth: true,
          admin: true,
          organizer: true,
        },
      },
      {
        path: "/admin/speakers",
        name: "adminSpeakers",
        component: SpeakersAdmin,
        meta: {
          requiresAuth: true,
          admin: true,
          organizer: true,
        },
      },
      {
        path: "/admin/speakers/create",
        name: "createSpeaker",
        component: createSpeaker,
        meta: {
          requiresAuth: true,
          admin: true,
          organizer: true,
        },
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

const homeRoutes = {
  '1': 'admin',
  '3': 'organizer',
  '4': 'attendee'
};

const goHome = (next) => {
  const group_id = localStorage.getItem('group_id');
  next({
    name: homeRoutes[group_id],
  })
};

router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth) {
    if (localStorage.getItem("token")) {
      if (to.meta.attendee) {
        if (localStorage.getItem('group_id') === '4') {
          next();
        }
        else {
          goHome(next);
        }
      } else if (to.meta.admin) {
        if (localStorage.getItem('group_id') === '1') {
          next();
        }
        else {
          goHome(next);
        }
      } else if (to.meta.organizer) {
        if (localStorage.getItem('group_id') === '3') {
          next();
        }
        else {
          goHome(next);
        }
      }
      next();
    } else {
      next({
        name: "login",
      });
      return;
    }
  } else {
    next();
    return;
  }
});

export default router;
