<template>
  <router-view />
</template>

<script>
import './styles/styles.scss';
export default {
  name: 'App'
};
</script>
