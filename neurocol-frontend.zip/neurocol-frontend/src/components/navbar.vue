<template>
  <nav class="navbar dark-bg">
    <div
      class="navbar__action__sidebar light-text light-font"
      @click="toggle_sidebar"
    >
      <Menu />
    </div>
    <h3 class="navbar__title light-text light-font">
      Semana del Cerebro, Colombia, 2021
    </h3>
    <div class="navbar__user light-text light-font">
      <account class="" />
      <ul class="user__menu dark-bg">
        <li class="user__menu__item" v-on:click="logout">
          <logout class="user__menu__item--icon" /><span
            class="user__menu__item--text"
            >Cerrar sesión</span
          >
        </li>
      </ul>
    </div>
  </nav>
</template>

<script>
import { Account, Logout, Menu } from "mdue";
import Storage from "../lib/storage";

const titleMap = {
  '1': 'Semana del Cerebro, Colombia, 2021',
  '3': 'Organizadores',
  '4': 'Asistentes'
};

export default {
  name: "Navbar",
  components: {
    Account,
    Logout,
    Menu,
  },
  beforeMount() {
    this.group = localStorage.getItem('group_id');
    this.title = titleMap[this.group];
  },
  methods: {
    logout() {
      localStorage.removeItem('user');
      localStorage.removeItem('token');
      localStorage.removeItem('group_id');
      this.$router.push("/login");
    },
    toggle_sidebar() {
      this.$emit("toggle-sidebar");
    },
  },
  data() {
    return {
      group: '',
      title: '',
    }
  }
};
</script>

<style scoped>
.navbar {
  position: fixed;
  top: 0;
  width: 100%;
  height: 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-direction: row;
  z-index: 3;
}

.navbar__action__sidebar {
  margin-left: 10px;
  height: 100%;
  display: flex;
  align-items: center;
  cursor: pointer;
}

.navbar__user {
  margin-right: 10px;
  height: 100%;
  display: flex;
  align-items: center;
}

.user__menu {
  display: none;
  position: fixed;
  margin: 0;
  padding: 5px 10px 5px 10px;
  top: 30px;
  right: 0;
  list-style: none;
  font-size: 0.8em;
}

.user__menu__item {
  padding: 5px 0 5px 0;
}

.user__menu__item--icon {
  margin-right: 10px;
}

.navbar__user:hover .user__menu,
.user__menu:hover {
  display: block;
}

.user__menu li:hover {
  text-decoration: underline;
  cursor: pointer;
}
</style>