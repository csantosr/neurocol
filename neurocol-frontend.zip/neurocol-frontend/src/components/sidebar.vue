<template>
  <div class="sidebar dark-bg light-text light-font">
    <ul>
      <li
        v-for="option in options"
        :key="option.title"
        :class="{
          sidebar__item: true,
          sidebar__item__active: false,
        }"
        @click="() => goTo(option.route)"
      >
        <component :is="option.IconComponent" class="sidebar__item--icon" />
        <span class="sidebar__item--text" v-show="open">{{ option.title }}</span>
      </li>
    </ul>
  </div>
</template>

<script>
/* eslint-disable vue/no-unused-components */
import { Calendar, TooltipAccount, Certificate, Home } from "mdue";

const optionsMap = {
  '1': [
    {
      title: 'Inicio',
      route: '/admin',
      IconComponent: Home,
    },
    {
      title: 'Eventos',
      route: '/admin/events',
      IconComponent: Calendar,
    },
    {
      title: 'Conferencistas',
      route: '/admin/speakers',
      IconComponent: TooltipAccount,
    }
  ],
  '3': [
    {
      title: 'Inicio',
      route: '/organizer',
      IconComponent: Home,
    },
    {
      title: 'Eventos',
      route: '/admin/events',
      IconComponent: Calendar,
    },
    {
      title: 'Conferencistas',
      route: '/admin/speakers',
      IconComponent: TooltipAccount,
    }
  ],
  '4': [
    {
      title: 'Inicio',
      route: '/attendee',
      IconComponent: Home,
    },
    {
      title: 'Certificados',
      route: '/attendee/certificate',
      IconComponent: Certificate,
    },
  ],
};

export default {
  name: "Sidebar",
  props: ["open"],
  components: {
    Calendar,
  },
  methods: {
    goTo(path) {
      this.$router.push(path);
    },
  },
  beforeMount() {
    this.group = localStorage.getItem('group_id');
    this.options = optionsMap[this.group];
  },
  // watch: {
  //   $route() {
  //     this.setActiveRoute();
  //   },
  // },
  data() {
    return {
      group: '',
      options: [],
    };
  },
};
</script>

<style scoped lang="scss">
.sidebar {
  padding: 10px 0 10px 0;
}
.sidebar ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.sidebar__item {
  display: flex;
  align-items: center;
  height: 30px;
  padding-left: 10px;
  padding-right: 10px;
}
.sidebar__item:hover {
  text-decoration: underline;
  cursor: pointer;
}
.sidebar__item--text {
  padding-left: 10px;
  white-space: nowrap;
}
.sidebar__item__active {
  border-left: 2px solid $primary;
}
</style>